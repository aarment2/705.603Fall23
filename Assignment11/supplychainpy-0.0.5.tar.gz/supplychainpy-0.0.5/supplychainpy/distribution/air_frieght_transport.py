class FreightPlane:
    def __init__(self):
        pass